<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
        <div class="header">

        </div>
        <div class="nav">
            <ul>
                <li style="background-color:#191970;"><a href="index.php" style="color:white;">Home</a></li>
                <li><a href="about.php">About</a></li>
            </ul>
        </div>
        <div class="abody">
            <form action="">
                <h3 class="head">LOGIN</h3>
                <br><br><br>
                <label class="label" for="">Username: </label>
                <input class="textbox" type="text" name="username" ><br>
                <label class="label" for="">Password:</label>
                <input class="textbox" type="password" name="password"><br><br><br>
                <input class="submit" type="submit" name="login" value="login">
                <br><br>
              <p class="new"><a href="register.php">New Register</a></p>
            </form>
        </div>
    </div>
</body>
</html>