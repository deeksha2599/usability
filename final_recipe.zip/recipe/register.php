<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
        <div class="header">

        </div>
        <div class="nav">
            <ul>
                <li style="background-color:#191970;"><a href="login.php" style="color:white;">Home</a></li>
                <li><a href="about.php">About</a></li>
            </ul>
        </div>
        <div class="abody">
            <form action="">
                <h3 class="head">REGISTER</h3>
                <br>
                <table>
                    <tr>
                        <td>
                        <label class="label" for="">Fullname: </label><br>
                <input class="textbox" type="text" name="fullname" ><br>
                        </td>
                        <td>
                        <label class="label" for="">Mobile: </label><br>
                <input class="textbox" type="text" name="mobile" ><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                        <label class="label" for="">Email: </label><br>
                <input class="textbox" type="text" name="email" ><br>
                        </td>
                        <td>
                        <label class="label" for="">Proffesion : </label><br>
                <input class="textbox" type="text" name="proffesion" ><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                        <label class="label" for="">Date Of Birth: </label><br>
                <input class="textbox" type="date" name="dob" ><br>
                        </td>
                        <td>
                        <label class="label" for="">Username: </label><br>
                <input class="textbox" type="text" name="username" ><br> 
                        </td>
                    </tr>
                    <tr>
                        <td>
                        <label class="label" for="">password: </label><br>
                <input class="textbox" type="text" name="pass" ><br>
                        </td>
                        <td>
                        <label class="label" for="">Confirm Password:</label>
                <input class="textbox" type="password" name="password"><br>
                        </td>
                    </tr>
                </table>
                <input class="submit" type="submit" name="login" value="Register">
                <br><br>
              <p class="new"><a href="login.php">Have An Account</a></p>
            </form>
        </div>
    </div>
</body>
</html>