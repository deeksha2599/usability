<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bcimage">
    <div>
        <div class="header">
           <p style="color:white; margin-left:200px; line-height:40px;">Welcome  Dhanu: ID 11522198</p>
        </div>
        <div class="navbar">
  <a href="userindex.php">Home</a>
  <a href="abouts.php">About</a>
  <div class="dropdown">
    <button class="dropbtn" >Add Recipe 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    <a href="add_recipe.php">veg</a>
    <a href="add_recipe.php">Rice</a>
    <a href="add_recipe.php">Home Remedies</a>
    </div>
  </div> 
  <a href="view.php">My Recipe</a>
  <a href="#logout.php">Logout</a>
  <h3 style="margin-left:1000px; line-height:40px; margin-top:20px;">Dhanu: ID 11522198</h3>
</div>
<div class="ibody" >
            <h1 style="color:white; background-color:#191970; width:700px; margin-top:200px; margin-left:400px; font-size:50px;">Recipe and Cooking procedure.</h1>
            <h3 style="color:#191970; background-color:white; width:300px; margin-top:30px; margin-left:550px; font-size:40px;">Join Us Today</h3>
        </div>
    </div>
</body>
</html>