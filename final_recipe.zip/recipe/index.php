<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bcimage">
    <div>
        <div class="header">
            <ul>
                <li><a href="login.php">Login|</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </div>
        <div class="nav">
            <ul>
                <li style="background-color:#191970;"><a href="index.php" style="color:white;">Home</a></li>
                <li><a href="about.php">About</a></li>
            </ul>
        </div>
        <div class="ibody" >
            <h1 style="color:white; background-color:#191970; width:700px; margin-top:200px; margin-left:400px; font-size:50px;">Recipe and Cooking procedure.</h1>
            <h3 style="color:#191970; background-color:white; width:300px; margin-top:30px; margin-left:550px; font-size:40px;">Join Us Today</h3>
        </div>
    </div>
</body>
</html>