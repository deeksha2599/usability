<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
        <div class="header">
           <p style="color:white; margin-left:200px; line-height:40px;">Welcome  Dhanu: ID 11522198</p>
        </div>
        <div class="navbar">
  <a href="userindex.php">Home</a>
  <a href="abouts.php">About</a>
  <div class="dropdown">
    <button class="dropbtn" >Add Recipe 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    <a href="add_recipe.php">Veg</a>
    <a href="add_recipe.php">Rice</a>
    <a href="add_recipe.php">Home Remedies</a>
    </div>
  </div> 
  <a href="view.php">My Recipe</a>
  <a href="#logout.php">Logout</a>
  <h3 style="margin-left:1000px; line-height:40px; margin-top:20px;">Dhanu: ID 11522198</h3>
</div>
<div class="about">
           <div class="image" style="float:left;">
               <img src="images/download (13).png" style="width:600px; height:400px; margin-left:50px; margin-top:50px;" alt="">
           </div>
           <div class="text" style="float:left; margin-left:100px; ">
           <br><br><br>
                <h1>Food Recipe Website</h1><br>
                <h3>We provide an easy platform to manage your cooking procedures</h3><br><br>
                <p>Create an account, log in to your account to have a full access of our webiste services.</p><br>
                <p>We offer a platform where you can upload new cooking procedures,<br><br>
                 view the different recipes from different system users <br><br> and also keep track of your own recipes.</p><br><br>
                 <p class="new"><a href="register.php">Register to be Part of Us</a></p>
           </div>
       </div>
    </div>
</body>
</html>