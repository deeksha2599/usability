<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
        <div class="header">
            <ul>
                <li><a href="login.php">Login|</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </div>
        <div class="nav">
            <ul>
                <li ><a href="index.php">Home</a></li>
                <li style="background-color:#191970;"><a style="color:white;" href="about.php">About</a></li>
            </ul>
        </div>
       <div class="about">
           <div class="image" style="float:left;">
               <img src="images/download (13).png" style="width:600px; height:400px; margin-left:50px; margin-top:50px;" alt="">
           </div>
           <div class="text" style="float:left; margin-left:100px; ">
           <br><br><br>
                <h1>Food Recipe Website</h1><br>
                <h3>We provide an easy platform to manage your cooking procedures</h3><br><br>
                <p>Create an account, log in to your account to have a full access of our webiste services.</p><br>
                <p>We offer a platform where you can upload new cooking procedures,<br><br>
                 view the different recipes from different system users <br><br> and also keep track of your own recipes.</p><br><br>
                 <p class="new"><a href="register.php">Register to be Part of Us</a></p>
           </div>
       </div>
    </div>
</body>
</html>