<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
        <div class="header">
           <p style="color:white; margin-left:200px; line-height:40px;">Welcome Deeksha : ID 11514967</p>
        </div>
        <div class="navbar">
  <a href="userindex.php">Home</a>
  <a href="abouts.php">About</a>
  <div class="dropdown">
    <button class="dropbtn" >Add Recipe 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    <a href="add_recipe.php">Veg</a>
    <a href="add_recipe.php">Rice</a>
    <a href="add_recipe.php">Home Remedies</a>
    </div>
  </div> 
  <a href="view.php">My Recipe</a>
  <a href="#logout.php">Logout</a>


  <h3 style="margin-left:1000px; line-height:40px; margin-top:20px;">Deeksha : ID 11514967</h3>
</div>
        <div class="ibody">
        <div class="row">
  <div class="column"> <h4 >Beverages</h4></div>
  <div class="column"><h4>Breads</h4></div>
  <div class="column"><h4>Curries</h4></div>
  <div class="column"><h4>Rice</h4></div>
  <div class="column"><h4>Desserts</h4></div>
  <div class="column"><h4>Starters</h4></div>
</div>
        </div>

        <div class="abody">
            <form action="">
                <h3 class="head">Add Recipe</h3>
                <br>
                <table>
                    <tr>
                        <td>
                        <label class="label" for="">Dish Name: </label><br>
                <input class="textbox" type="text" name="username" ><br>
                        </td>
                        <td><label class="label" for="">Duration: </label><br>
                <input class="textbox" type="text" name="username" ><br></td>
                    </tr>
                   
                </table>
                <label for="">Cooking Tasks</label><br>
               <textarea name="" id="" cols="63" rows="3" placeholder="the cooking prerequistes"></textarea><br><br>
                <label for="">Cooking Equipment</label><br>
               <textarea name="" id="" cols="63" rows="3" placeholder="list the equipments"></textarea><br><br>
               <label for="">Cooking Procedure</label><br>
               <textarea name="" id="" cols="63" rows="3" placeholder="Cooking Procedure"></textarea>
               <br><br>
                <input class="submit" type="submit" name="login" value="Add Recipe">
                <br><br>
            </form>
        </div>
    </div>
</body>
</html>