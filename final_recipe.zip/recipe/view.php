<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
        <div class="header">
           <p style="color:white; margin-left:200px; line-height:40px;">Welcome  Dhanu: ID 11522198</p>
        </div>
        <div class="navbar">
  <a href="userindex.php">Home</a>
  <a href="abouts.php">About</a>
  <div class="dropdown">
    <button class="dropbtn" >Add Recipe 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
    <a href="add_recipe.php">Veg</a>
    <a href="add_recipe.php">Rice</a>
    <a href="add_recipe.php">Home Remedies</a>
    </div>
  </div> 
  <a href="view.php">My Recipe</a>
  <a href="#logout.php">Logout</a>
  <h3 style="margin-left:1000px; line-height:40px; margin-top:20px;">Dhanu: ID 11522198</h3>
</div>
<br>
<form action="search_result.php" method="post" >
    <input type="text" style="width:350px; height:30px; margin-bottom:10px; margin-top:-10px; margin-left:500px; border-radius:30px;" placeholder="search here">
    <input  style="color:white; font-size:18px; padding:3px; font-style:italic; background-color:#B22222" type="submit" name="search" value="search Recipe">
</form>
<center>
<h1>Recipe list</h1>
</center>


<table id="customers">
  <tr>
    <th>Recipe Name</th>
    <th>Duration</th>
    <th>Ingredients List</th>
    <th>Procedure</th>
  </tr>
  <tr>
    <td>Rice</td>
    <td>30 Minutes</td>
    <td>Rice, Water, Salt, Ginger, Garlic</td>
    <td>into warm water, add cooking oil and salt.
      wait for it to boil
      add your washed rice.
      cook under low heat.
    </td>
  </tr>
  <tr>
    <td>Rice</td>
    <td>30 Minutes</td>
    <td>Rice, Water, Salt, Ginger, Garlic</td>
    <td>into warm water, add cooking oil and salt.
      wait for it to boil
      add your washed rice.
      cook under low heat.
    </td>
  </tr>
  <tr>
    <td>Rice</td>
    <td>30 Minutes</td>
    <td>Rice, Water, Salt, Ginger, Garlic</td>
    <td>into warm water, add cooking oil and salt.
      wait for it to boil
      add your washed rice.
      cook under low heat.
    </td>
  </tr>
  <tr>
    <td>Rice</td>
    <td>30 Minutes</td>
    <td>Rice, Water, Salt, Ginger, Garlic</td>
    <td>into warm water, add cooking oil and salt.
      wait for it to boil
      add your washed rice.
      cook under low heat.
    </td>
  </tr>
</table>
    </div>
</body>
</html>